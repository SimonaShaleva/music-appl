package com.example.spring_exam.model.entity;

public enum ArtistEnum {
    QUEEN, METALLICA, MADONNA
}
