package com.example.spring_exam.model.entity;

public enum GenreEnum {
    POP, ROCK, METAL, OTHER
}
