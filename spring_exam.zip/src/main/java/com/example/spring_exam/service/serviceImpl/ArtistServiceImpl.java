package com.example.spring_exam.service.serviceImpl;

import com.example.spring_exam.model.entity.Artist;
import com.example.spring_exam.model.entity.ArtistEnum;
import com.example.spring_exam.repository.ArtistRepository;
import com.example.spring_exam.service.ArtistService;
import org.springframework.stereotype.Service;

@Service
public class ArtistServiceImpl implements ArtistService {
    private final ArtistRepository artistRepository;

    public ArtistServiceImpl(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    @Override
    public void initArtists() {
        if (artistRepository.count() != ArtistEnum.values().length) {
            for (ArtistEnum a : ArtistEnum.values()) {
                artistRepository.save(new Artist(a));
            }
        }
    }

    @Override
    public Artist findByArtist(ArtistEnum artist) {
        return artistRepository.findByArtist(artist);
    }
}
