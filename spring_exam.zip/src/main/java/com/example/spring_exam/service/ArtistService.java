package com.example.spring_exam.service;

import com.example.spring_exam.model.entity.Artist;
import com.example.spring_exam.model.entity.ArtistEnum;

public interface ArtistService {
    void initArtists();

    Artist findByArtist(ArtistEnum artist);
}
