package com.example.spring_exam.service;

import com.example.spring_exam.model.service.AlbumServiceModel;
import com.example.spring_exam.model.view.AlbumViewModel;

import java.util.List;

public interface AlbumService {
    void addAlbum(AlbumServiceModel albumServiceModel);

    Long findTotalCopies();

    List<AlbumViewModel> findAllAlbums();

    void deleteById(Long id);
}
